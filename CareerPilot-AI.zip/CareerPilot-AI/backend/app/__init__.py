"""CareerPilot AI Application Package"""
